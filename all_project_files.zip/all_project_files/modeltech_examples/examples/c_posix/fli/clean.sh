#! /bin/sh
rm -f transcript *.wlf core* workingExclude.cov
rm -f *.dll *.exp *.lib *.obj *.sl *.o *.so 
rm -f vsim_stacktrace.vstf *.h
rm -rf work
exit 0
